import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-podium',
  templateUrl: './add-podium.component.html',
  styleUrls: ['./add-podium.component.css']
})
export class AddPodiumComponent implements OnInit {
 addUserImage = '../assets/usericon.png';
  constructor() { }

  ngOnInit() {
  }

}

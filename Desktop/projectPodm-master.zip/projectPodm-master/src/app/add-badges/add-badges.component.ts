import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-badges',
  templateUrl: './add-badges.component.html',
  styleUrls: ['./add-badges.component.css']
})
export class AddBadgesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

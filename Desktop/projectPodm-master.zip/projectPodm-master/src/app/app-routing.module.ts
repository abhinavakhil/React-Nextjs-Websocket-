import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ViewPodiumComponent } from './view-podium/view-podium.component';
import { LoginComponent } from './login/login.component';
import { PasswordComponent } from './password/password.component';
import { BlankComponent } from './blank/blank.component';

const routes: Routes = [
  {path:'view-podium',component:ViewPodiumComponent},
  {path:'view-podium/:id',component:ViewPodiumComponent},
  {path:'password',component:PasswordComponent},
  {path:'blank',component:BlankComponent},
  {path:'',component:LoginComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

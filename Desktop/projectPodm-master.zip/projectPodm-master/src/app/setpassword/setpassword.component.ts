import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-setpassword',
  templateUrl: './setpassword.component.html',
  styleUrls: ['./setpassword.component.css']
})
export class SetpasswordComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

export interface PodiumItems{
 created_at:string;
 created_by:string;
 group_description:string;
 group_image:string;
 group_name:string;
 last_message_added:number;
 open:number;
 type_id:number;
 updated_at:string;
 userid:string;
 users:any[];


//  constructor(created_at:Date,
//              created_by:string,
//              group_description:string,
//              group_image:string,
//              group_name:string,
//              open:number,type_id:number,updated_at:Date,
//              userid:string,users:any[]
//              )
//               {
//                 this.created_at = created_at;

//                 this.created_by = created_by;
//                 this.group_description = group_description;
//                 this.group_image = group_image;
//                 this.group_name = group_name;
//                 this.open = open;
//                 this.type_id = type_id;
//                 this.updated_at = updated_at;
//                 this.userid = userid;
//                 this.users = users;
//               }
}
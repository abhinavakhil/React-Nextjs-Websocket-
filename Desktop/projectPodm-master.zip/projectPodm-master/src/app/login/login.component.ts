import { Component, OnInit, Input } from '@angular/core';
import * as firebase from 'firebase';
import { environment } from 'src/environments/environment';
import { AngularFirestore, AngularFirestoreCollection } from '@angular/fire/firestore';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';
import { LoginService } from '../service/login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  
  data:Observable<any>;
  MyphoneNumber ;

  constructor(private firestore:AngularFirestore,
              private router: Router,
              private loginService:LoginService) { }

  ngOnInit() {
   
  }

   
 
  sendLoginCode(formData){   
       
      this.data = this.firestore.collection("users",ref => ref.where('phone_no','==' ,'+91'+formData.MyphoneNumber)).valueChanges();
      this.data.subscribe(result => {
        this.data = result;
        localStorage.setItem('key','+91'+formData.MyphoneNumber);
         //console.log('+91'+formData.MyphoneNumber);
        //for checking if phone no matches the number typed
        if(this.data[0].phone_no == '+91'+formData.MyphoneNumber){
          this.router.navigate(['/password']);
          //return this.data;
        }
        else{
          console.log('number didnot matched');
        }
      }) 
      
    }
 
}
 
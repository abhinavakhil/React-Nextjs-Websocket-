import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { SetpasswordComponent } from './setpassword/setpassword.component';
import { BlankComponent } from './blank/blank.component';
import { ViewPodiumComponent } from './view-podium/view-podium.component';
import { AddPodiumComponent } from './add-podium/add-podium.component';
import { AddBadgesComponent } from './add-badges/add-badges.component';
import { BadgeViewComponent } from './badge-view/badge-view.component';
import { AlbumsComponent } from './albums/albums.component';
import { PodiumlistComponent } from './podiumlist/podiumlist.component';
import { PodiumFeedComponent } from './podium-feed/podium-feed.component';
import { ViewlistComponent } from './viewlist/viewlist.component';


// firebase Modules
import { AngularFireModule } from '@angular/fire';
//import * as firebase from 'firebase';
import { environment } from '../environments/environment';
//import { WindowService } from './window.service';
import { AngularFirestoreModule } from 'angularfire2/firestore';
import { PasswordComponent } from './password/password.component';
import { UserdataService } from './service/userdata.service';
import { LoginService } from './service/login.service';
import { NavigationComponent } from './navigation/navigation.component';
import { PostService } from './service/post.service';
import { CookieService } from 'ngx-cookie-service';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    SetpasswordComponent,
    BlankComponent,
    ViewPodiumComponent,
    AddPodiumComponent,
    AddBadgesComponent,
    BadgeViewComponent,
    AlbumsComponent,
    PodiumlistComponent,
    PodiumFeedComponent,
    ViewlistComponent,
    PasswordComponent,
    NavigationComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule.forRoot(),
    FormsModule,
    AngularFireModule.initializeApp(environment.firebase), 
    AngularFirestoreModule 
  ],
  providers: [
              AngularFirestoreModule,
              UserdataService,
              LoginService,
              PostService,
              CookieService 
             ],
  bootstrap: [AppComponent]
})
export class AppModule { }

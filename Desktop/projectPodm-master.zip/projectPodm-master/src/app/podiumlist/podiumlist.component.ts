import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-podiumlist',
  templateUrl: './podiumlist.component.html',
  styleUrls: ['./podiumlist.component.css']
})
export class PodiumlistComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

export const environment = {
  production: true,
  firebase:{
    apiKey: "AIzaSyBp45cfWcPXl_m2ibv_wN2art3tX3iJe8Y",
    authDomain: "podium-web-dev.firebaseapp.com",
    databaseURL: "https://podium-web-dev.firebaseio.com",
    projectId: "podium-web-dev",
    storageBucket: "podium-web-dev.appspot.com",
    messagingSenderId: "928655589313",
    appId: "1:928655589313:web:7c1cfbc0e5bacf25"
  }
};
